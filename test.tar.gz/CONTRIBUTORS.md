# Contributors

* Initial `tac` development and AVX2 SIMD implementation by Mahmoud Al-Qudsi (@mqudsi)
* NEON SIMD acceleration for aarch64 by @unrelentingtech
